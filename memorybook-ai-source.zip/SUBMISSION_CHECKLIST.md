# Course Project Submission Checklist

- [x] Problem statement and project scope
- [x] Runnable offline MVP
- [x] README with setup and privacy boundary
- [x] Ten synthetic evaluation cases and generated results
- [x] Architecture explanation
- [x] Final report draft
- [x] Five-minute demo script
- [ ] Record a five-minute video with your face and the terminal/screen visible
- [ ] Convert the final report draft to PDF after personal review
- [ ] Add a link to the demo video in the README or upload the video if the submission folder accepts it
- [ ] Create the final ZIP without raw interviews, recordings or identifiable transcripts
