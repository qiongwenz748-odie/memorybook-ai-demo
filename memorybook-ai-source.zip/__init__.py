"""Evidence-grounded MemoryBook AI prototype."""
