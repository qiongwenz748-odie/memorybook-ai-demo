# Architecture

```text
Narrated memory
      |
      v
Transcript input ----> explicit fact extractor ----> evidence-backed memory record
                                                        |             |
                                                        |             +--> user review/correction
                                                        v
Fixed-question baseline <---- adaptive question selector
                                                        |
                                                        v
                                            conservative draft generator
                                                        |
                                                        v
                                  paragraph plus evidence identifiers E1...En
```

The production direction is speech-to-text plus a retrieval-augmented language model. The submitted MVP uses an explicit, offline fact format so every output claim can be traced and the project can be evaluated without uploading private autobiographical data.
