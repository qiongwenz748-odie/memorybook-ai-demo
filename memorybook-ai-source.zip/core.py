from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import re
from typing import Iterable


@dataclass(frozen=True)
class Fact:
    kind: str
    value: str
    evidence_id: str
    source_excerpt: str


@dataclass
class MemoryRecord:
    record_id: str
    transcript: str
    facts: list[Fact] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def evidence_map(self) -> dict[str, str]:
        return {fact.evidence_id: fact.source_excerpt for fact in self.facts}

    def to_dict(self) -> dict:
        return {"record_id": self.record_id, "transcript": self.transcript, "facts": [asdict(f) for f in self.facts], "created_at": self.created_at}


PATTERNS: dict[str, re.Pattern[str]] = {
    "person": re.compile(r"\bPERSON:\s*([^;\n]+)", re.IGNORECASE),
    "date": re.compile(r"\bDATE:\s*([^;\n]+)", re.IGNORECASE),
    "location": re.compile(r"\bLOCATION:\s*([^;\n]+)", re.IGNORECASE),
    "event": re.compile(r"\bEVENT:\s*([^;\n]+)", re.IGNORECASE),
}


def extract_facts(transcript: str, record_id: str = "memory-001") -> MemoryRecord:
    """Extract only explicitly labelled facts to avoid silently inventing memories."""
    facts: list[Fact] = []
    sequence = 1
    for kind, pattern in PATTERNS.items():
        for match in pattern.finditer(transcript):
            value = match.group(1).strip().rstrip(".")
            excerpt = match.group(0).strip()
            facts.append(Fact(kind, value, f"E{sequence}", excerpt))
            sequence += 1
    return MemoryRecord(record_id=record_id, transcript=transcript, facts=facts)


def facts_by_kind(record: MemoryRecord) -> dict[str, list[Fact]]:
    grouped: dict[str, list[Fact]] = {kind: [] for kind in PATTERNS}
    for fact in record.facts:
        grouped.setdefault(fact.kind, []).append(fact)
    return grouped


def next_adaptive_question(record: MemoryRecord) -> str:
    grouped = facts_by_kind(record)
    questions = {
        "event": "What happened that you would most like future family members to understand?",
        "date": "About when did this memory take place? An approximate year is fine.",
        "location": "Where did this memory take place?",
        "person": "Who else was involved, and how would you like them described?",
    }
    for kind in ("event", "date", "location", "person"):
        if not grouped.get(kind):
            return questions[kind]
    return "What feeling or lesson would you like to add, in your own words?"


def fixed_baseline_questions() -> list[str]:
    return [
        "Who was involved?",
        "When did it happen?",
        "Where did it happen?",
        "What happened?",
    ]


def _first(grouped: dict[str, list[Fact]], kind: str) -> Fact | None:
    values = grouped.get(kind, [])
    return values[0] if values else None


def draft_paragraph(record: MemoryRecord) -> dict[str, object]:
    """Generate a short draft only from explicit extracted facts.

    The returned evidence list is the audit trail for the paragraph. If there is
    no event, the method declines to write narrative prose instead of guessing.
    """
    grouped = facts_by_kind(record)
    event = _first(grouped, "event")
    if event is None:
        return {
            "status": "needs_clarification",
            "paragraph": "I do not yet have enough evidence to write this memory. " + next_adaptive_question(record),
            "evidence_ids": [],
        }
    person = _first(grouped, "person")
    date = _first(grouped, "date")
    location = _first(grouped, "location")
    evidence: list[str] = [event.evidence_id]
    if date:
        evidence.append(date.evidence_id)
    if person:
        evidence.append(person.evidence_id)
    if date and person:
        lead = f"In {date.value}, {person.value} described how"
    elif person:
        lead = f"{person.value} described how"
    elif date:
        lead = f"In {date.value}, this memory records how"
    else:
        lead = "This memory records how"
    place = f" in {location.value}" if location else ""
    if location:
        evidence.append(location.evidence_id)
    paragraph = f"{lead} {event.value}{place}."
    return {"status": "grounded", "paragraph": paragraph, "evidence_ids": evidence}


def evaluate_case(case: dict) -> dict:
    record = extract_facts(case["transcript"], case["id"])
    extracted = {(fact.kind, fact.value) for fact in record.facts}
    expected = {(item["kind"], item["value"]) for item in case["expected_facts"]}
    draft = draft_paragraph(record)
    return {
        "id": case["id"],
        "expected_count": len(expected),
        "extracted_count": len(extracted),
        "exact_match": extracted == expected,
        "unsupported_claim": draft["status"] == "grounded" and not draft["evidence_ids"],
        "adaptive_question": next_adaptive_question(record),
    }


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / len(values) if values else 0.0
