from __future__ import annotations

import json

from .core import draft_paragraph, extract_facts, next_adaptive_question


DEMO_TRANSCRIPT = """PERSON: Mei Lin; DATE: 1978; LOCATION: Guangzhou;
EVENT: she opened a small tailor shop with her sister after saving for three years."""


def main() -> None:
    record = extract_facts(DEMO_TRANSCRIPT, "demo-001")
    print("Extracted evidence")
    print(json.dumps(record.to_dict(), ensure_ascii=False, indent=2))
    print("\nAdaptive follow-up")
    print(next_adaptive_question(record))
    print("\nFact-grounded draft")
    print(json.dumps(draft_paragraph(record), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
