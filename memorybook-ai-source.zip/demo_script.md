# Five Minute Demo Script

## 0:00 to 0:25 - Introduce the problem

"MemoryBook AI helps an older adult turn a narrated memory into a short autobiography paragraph without losing the evidence behind each claim. The risk I am addressing is silent hallucination: a fluent draft that changes a name, date or event."

## 0:25 to 1:10 - Show architecture

Show `docs/architecture.md`. Explain that production speech-to-text and an LLM would sit behind the workflow, while this submitted MVP is offline and deterministic so it can be reviewed without private audio or an API key.

## 1:10 to 2:35 - Run one successful case

Run:

```powershell
python -m memorybook.demo
```

Show the four source excerpts, evidence identifiers E1 to E4, the generated paragraph, and the list of evidence identifiers returned with that paragraph. State that the paragraph only includes information contained in the record.

## 2:35 to 3:20 - Show safe failure

Run the missing-event unit test or show its code. Explain that when the memory lacks an EVENT, the generator returns `needs_clarification` rather than writing a plausible sentence. This is the project’s key responsible-AI behaviour.

## 3:20 to 4:20 - Show evaluation

Run:

```powershell
python -m memorybook.evaluate
```

Show the result: 10 synthetic cases, 100% exact match and 0% unsupported-claim check. Clearly say these are deterministic synthetic fixtures, not a claim of real-world accuracy.

## 4:20 to 5:00 - Reflect and close

State the limitation: no speech input, open-ended extraction or user study yet. State the next step: consented speech-to-text, evidence-constrained RAG and a comparison of adaptive questions against the fixed-question baseline. End with: "For personal memories, evidence and user review matter as much as fluent prose."
