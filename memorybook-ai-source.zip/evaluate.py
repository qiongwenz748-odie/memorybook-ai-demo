from __future__ import annotations

import json
from pathlib import Path

from .core import evaluate_case, mean


def main() -> None:
    case_path = Path(__file__).parents[1] / "evals" / "cases.json"
    cases = json.loads(case_path.read_text(encoding="utf-8"))
    results = [evaluate_case(case) for case in cases]
    accuracy = mean(float(result["exact_match"]) for result in results)
    unsupported = mean(float(result["unsupported_claim"]) for result in results)
    output = {
        "case_count": len(results),
        "fact_extraction_exact_match": accuracy,
        "unsupported_claim_rate": unsupported,
        "results": results,
        "interpretation": "This is deterministic synthetic-fixture evaluation. It validates the MVP's evidence binding, not real-world speech recognition or LLM quality.",
    }
    output_path = Path(__file__).parents[1] / "evals" / "results.json"
    output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
