# MemoryBook AI Final Project Report

## 1. Problem and significance

Older adults often carry decades of family, work and community memories, yet converting spoken recollections into a reliable written autobiography is difficult. Writing and editing can be demanding; family members may not be available to interview them; and generic generative AI can produce polished prose that silently changes names, dates or events. That failure is especially harmful in a life story because a plausible error can become part of a family's record.

MemoryBook AI is a prototype for a fact-grounded autobiography assistant. The initial audience is older adults in China who are comfortable narrating memories but less comfortable composing and publishing long text. Family members are secondary users: they can help record a conversation, review evidence and preserve the final story. The broader domain is generative AI for digital legacy and personal storytelling. The project asks a narrow question: can a system turn an explicitly evidenced memory into a readable paragraph while retaining an audit trail for every claim?

This scope reflects a real social need but does not claim that one prototype solves loneliness, ageing or family archiving. The value proposition is modest and testable: reduce the effort of structuring a short memory while preserving user control over factual claims.

## 2. Solution and technical choices

The system follows a build-and-buy design. A production version would combine speech-to-text, a foundation model and retrieval-augmented generation. These are commodity capabilities that should not be rebuilt from zero. The project-specific layer is the workflow around them: a structured memory store, evidence identifiers, adaptive follow-up questions, conservative generation and user review.

The submitted MVP is deliberately offline and deterministic. Instead of calling a cloud model, it receives a structured transcript with explicit PERSON, DATE, LOCATION and EVENT labels. It extracts those facts, assigns evidence identifiers, stores the source excerpt separately, asks a question for the first important missing element, and generates a paragraph only when an event is present. The paragraph returns its evidence identifiers alongside the text. If no event has been captured, the system abstains and asks for clarification rather than inventing a narrative.

This is not a shortcut to claim that a rule-based parser is a full AI interviewer. It is an executable, auditable minimum slice of the proposed architecture. It demonstrates the project decision that evidence control is more important than fluent but untraceable prose. A future version can replace the extractor with speech recognition and a retrieval-augmented model while preserving the same evidence contract.

## 3. Data, privacy and responsible use

The project uses ten synthetic and anonymised life-story cases for evaluation. No real interview recordings, names, contact details or identifiable transcripts are included in the repository. The proposal identifies the MuPe Life Stories Dataset as a possible benchmark source, but this MVP does not redistribute it or use it as a proxy for Chinese users. Four exploratory interviews mentioned in the problem statement remain outside the repository and must only be used with explicit consent and anonymisation.

Personal storytelling data deserves stronger controls than ordinary product telemetry. Users should be able to see the evidence behind each generated sentence, correct a transcript, remove a memory and decide whether a draft may be shared. The key silent failure is a fabricated detail presented as a real memory. MemoryBook reduces this risk by keeping source excerpts separate from generated prose, requiring evidence identifiers, and abstaining when essential information is missing. It does not eliminate risk: a supplied transcript can still be wrong, an extractor can label text incorrectly, and a user might approve a draft without carefully reviewing it.

## 4. Evaluation design and results

The evaluation harness contains ten synthetic cases. Each has an independently specified set of person, date, location and event facts. The program compares extracted facts against the answer key, checks whether a generated paragraph has evidence identifiers, and records the adaptive follow-up question. The command `python -m memorybook.evaluate` writes the complete result to `evals/results.json`.

On the ten controlled fixtures, exact fact extraction was 10/10 (100%) and the unsupported-claim check was 0/10 (0%). These figures are reproducible because the parser is deterministic and the fixtures use its documented explicit-label format. They validate wiring: each expected fact is preserved, each draft carries evidence, and missing-event cases cause abstention. They do not validate speech recognition, conversational quality, factual accuracy in open-ended language or model robustness. Presenting them as a real-user accuracy result would be misleading.

The fixed-question baseline always asks who, when, where and what. The adaptive workflow instead asks only for the first missing core element, avoiding unnecessary repetition when a speaker has already supplied information. This comparison is currently a design-level comparison rather than a user study. A next evaluation should recruit consented participants, pre-register annotation rules, compare factual coverage and correction workload, and report confidence intervals rather than relying on a small synthetic fixture set.

## 5. Critical reflection and next steps

The strongest aspect of the MVP is traceability. A reviewer can inspect one record, see its four source excerpts, read the drafted paragraph and check the evidence identifiers. The tests also demonstrate the intended safety behaviour: without an event, the generator does not fill in a plausible story. This is a better product constraint than asking a model to "be accurate" without a mechanism for checking accuracy.

The largest limitation is that the prototype is not yet a natural spoken conversation. It requires explicit labels, does not process audio, has no semantic retrieval, and cannot distinguish contradictory accounts. The current evaluation is intentionally narrow. The 100% fixture score shows deterministic correctness under a designed input contract; it is not evidence that the system is ready for deployment. Another limitation is accessibility: older adults may prefer voice interaction, larger interfaces and a family-assisted review flow.

The next iteration should introduce consented speech-to-text, a structured event schema, retrieval over approved memory entries, and an LLM constrained to retrieved evidence. It should log corrections, measure unsupported-claim rate through human annotation, and test whether adaptive questioning improves event coverage relative to the fixed-question baseline. The product should include deletion, export and sharing controls before any genuine life stories are retained.

## 6. Conclusion

MemoryBook AI demonstrates a feasible starting point for fact-grounded autobiography support. Its contribution is not a claim of sophisticated language generation; it is a reproducible workflow in which a narrative draft is paired with the evidence used to create it. For a domain where fabricated memories are unacceptable, that constraint is an essential product feature rather than an implementation detail.
