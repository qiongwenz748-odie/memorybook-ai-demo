import unittest

from memorybook.core import draft_paragraph, extract_facts, next_adaptive_question


class MemoryBookTests(unittest.TestCase):
    def test_grounded_draft_cites_all_available_facts(self):
        record = extract_facts("PERSON: Lin; DATE: 1968; LOCATION: Shanghai; EVENT: she attended university.")
        draft = draft_paragraph(record)
        self.assertEqual(draft["status"], "grounded")
        self.assertEqual(set(draft["evidence_ids"]), {"E1", "E2", "E3", "E4"})
        self.assertIn("attended university", draft["paragraph"])
        self.assertIn("In 1968, Lin described how", draft["paragraph"])

    def test_missing_event_abstains(self):
        record = extract_facts("PERSON: Lin; DATE: 1968; LOCATION: Shanghai;")
        draft = draft_paragraph(record)
        self.assertEqual(draft["status"], "needs_clarification")
        self.assertIn("What happened", next_adaptive_question(record))


if __name__ == "__main__":
    unittest.main()
